def handler(event:, context:)
  puts 'Hello from Dummy Lambda!'
  return event
end